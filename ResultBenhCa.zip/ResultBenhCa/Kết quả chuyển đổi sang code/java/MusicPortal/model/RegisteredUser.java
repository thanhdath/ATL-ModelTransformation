package MusicPortal.model;


public class RegisteredUser {

    private void viewOwnedAlbumList() {
    }

    private void downloadAlbum() {
    }

    private void recharge() {
    }

    private void viewAccount() {
    }

    private void buyAlbum() {
    }

    private void logout() {
    }
}
