package MusicPortal.model;


public class User {

    private void searchAlbum() {
    }

    private void viewAlbumDetails() {
    }

    private void register() {
    }

    private void login() {
    }
}
