package FishDisease.service;

@Service
public class ReviewService {

	public void SaveReview() {
		
	}
}
