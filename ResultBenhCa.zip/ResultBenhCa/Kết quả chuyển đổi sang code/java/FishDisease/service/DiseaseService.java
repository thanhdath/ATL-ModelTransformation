package FishDisease.service;

@Service
public class DiseaseService {
}
