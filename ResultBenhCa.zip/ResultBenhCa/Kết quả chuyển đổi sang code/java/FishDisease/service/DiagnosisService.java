package FishDisease.service;

@Service
public class DiagnosisService {

	public void DataValidation(String name, String sympton) {
		
	}

	public void SaveDiagnosis() {
		
	}
}
