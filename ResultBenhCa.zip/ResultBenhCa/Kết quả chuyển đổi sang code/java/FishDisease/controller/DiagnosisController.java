package FishDisease.controller;

@Controller
public class DiagnosisController {
	@GetMapping("/viewsaveddiagnosis")
	public String viewsaveddiagnosis(Model model) {
		return "";
	}
}
