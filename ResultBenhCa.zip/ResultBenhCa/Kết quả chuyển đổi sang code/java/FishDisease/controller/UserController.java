package FishDisease.controller;

@Controller
public class UserController {
	@GetMapping("/viewprofile")
	public String viewprofile(Model model) {
		return "";
	}
	@GetMapping("/viewprofileinfo")
	public String viewprofileinfo(Model model) {
		return "";
	}
}
