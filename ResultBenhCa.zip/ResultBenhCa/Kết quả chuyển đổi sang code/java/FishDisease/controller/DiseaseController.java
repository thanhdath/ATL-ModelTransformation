package FishDisease.controller;

@Controller
public class DiseaseController {
	@GetMapping("/searchdiseaseinfo")
	public String searchdiseaseinfo(Model model) {
		return "";
	}
	@GetMapping("/viewdiseaseinfo")
	public String viewdiseaseinfo(Model model) {
		return "";
	}
}
