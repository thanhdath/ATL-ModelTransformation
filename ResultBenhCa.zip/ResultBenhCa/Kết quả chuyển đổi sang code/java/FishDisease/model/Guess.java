package FishDisease.model;


public class Guess {
}
