package FishDisease.model;


public class User {
}
