package FishDisease.model;


public class Review {
	private Float rating;
	private String comment;

	public Float getRating() {
		return rating;
	}

	public String getComment() {
		return comment;
	}

	public void setRating(Float rating) {
		this.rating = rating;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
}
